#include <ESP32Servo.h>

Servo myServo;

// Pins
#define PIR_PIN 13
#define LED_PIN 14
#define BUZZER_PIN 27
#define SERVO_PIN 18

void setup() {
  Serial.begin(115200);

  pinMode(PIR_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  myServo.attach(SERVO_PIN);

  Serial.println("ESP32 Round Robin Simulation Start");
}

void loop() {

  // TASK 1 - PIR Sensor
  Serial.println("Task 1: Sensor Reading");

  int motion = digitalRead(PIR_PIN);
  Serial.println(motion ? "Motion Detected" : "No Motion");

  delay(1000);

  // TASK 2 - LED
  Serial.println("Task 2: LED Blink");

  digitalWrite(LED_PIN, HIGH);
  delay(300);
  digitalWrite(LED_PIN, LOW);
  delay(300);

  // TASK 3 - BUZZER
  Serial.println("Task 3: Buzzer");

  digitalWrite(BUZZER_PIN, HIGH);
  delay(300);
  digitalWrite(BUZZER_PIN, LOW);
  delay(300);

  // TASK 4 - SERVO
  Serial.println("Task 4: Servo Move");

  myServo.write(0);
  delay(500);

  myServo.write(90);
  delay(500);

  myServo.write(180);
  delay(500);

  Serial.println("----------------------");
}